const roleMiddleware = (...roles) => {
  return (req, res, next) => {
    console.log("REQ USER:", req.user);

    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized"
      });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: "Akses ditolak"
      });
    }

    next();
  };
};

module.exports = roleMiddleware;