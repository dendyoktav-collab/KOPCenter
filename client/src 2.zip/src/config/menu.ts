import type { ElementType } from "react";

import {
  Dashboard,
  Group,
  School,
  ReceiptLong,
  Savings,
  AccountBalance,
  CreditCard,
  PointOfSale,
  Store,
  SportsTennis,
  EmojiEvents,
  Badge,
  Warehouse,
  Inventory2,
  ShoppingCart,
  Payments,
  AccountBalanceWallet,
  TrendingUp,
  Apartment,
  Campaign,
  Wallet,
  FactCheck,
  Calculate,
  Folder,
  Assessment,
  Settings,
} from "@mui/icons-material";

export interface MenuItem {
  id: string;
  title: string;
  path?: string;
  icon?: ElementType;
  permission?: string;
  children?: MenuItem[];
}

const menu: MenuItem[] = [
  {
    id: "dashboard",
    title: "Dashboard",
    path: "/dashboard",
    icon: Dashboard,
  },

  // =====================================================
  // MASTER DATA
  // =====================================================

  {
    id: "master",
    title: "Master Data",
    icon: Group,

    children: [
      {
        id: "anggota",
        title: "Anggota",
        path: "/master/anggota",
      },

      {
        id: "atlet",
        title: "Atlet",
        path: "/master/atlet",
      },

      {
        id: "orang-tua",
        title: "Orang Tua",
        path: "/master/orang-tua",
      },

      {
        id: "pelatih",
        title: "Pelatih",
        path: "/master/pelatih",
      },

      {
        id: "karyawan",
        title: "Karyawan",
        path: "/master/karyawan",
      },

      {
        id: "pengurus",
        title: "Pengurus",
        path: "/master/pengurus",
      },

      {
        id: "investor",
        title: "Investor",
        path: "/master/investor",
      },

      {
        id: "donatur",
        title: "Donatur",
        path: "/master/donatur",
      },

      {
        id: "sponsor",
        title: "Sponsor",
        path: "/master/sponsor",
      },

      {
        id: "supplier-master",
        title: "Supplier",
        path: "/master/supplier",
      },

      {
        id: "mitra",
        title: "Mitra",
        path: "/master/mitra",
      },

      {
        id: "customer",
        title: "Customer",
        path: "/master/customer",
      },

      {
        id: "cabang",
        title: "Cabang",
        path: "/master/cabang",
      },

      {
        id: "gudang-master",
        title: "Gudang",
        path: "/master/gudang",
      },
    ],
  },

  // =====================================================
  // AKADEMI
  // =====================================================

  {
    id: "academy",
    title: "Akademi",
    icon: School,

    children: [
      {
        id: "academy-register",
        title: "Pendaftaran Atlet",
        path: "/academy/register",
      },

      {
        id: "academy-class",
        title: "Kelas",
        path: "/academy/class",
      },

      {
        id: "academy-schedule",
        title: "Jadwal",
        path: "/academy/schedule",
      },

      {
        id: "academy-attendance",
        title: "Absensi",
        path: "/academy/attendance",
      },

      {
        id: "academy-ranking",
        title: "Ranking",
        path: "/academy/ranking",
      },

      {
        id: "academy-achievement",
        title: "Prestasi",
        path: "/academy/achievement",
      },

      {
        id: "academy-scholarship",
        title: "Beasiswa",
        path: "/academy/scholarship",
      },
    ],
  },

  // =====================================================
  // TAGIHAN AKADEMI
  // =====================================================

  {
    id: "academy-billing",
    title: "Tagihan Akademi",
    icon: ReceiptLong,

    children: [
      {
        id: "billing-spp",
        title: "SPP",
        path: "/billing/spp",
      },

      {
        id: "billing-uniform",
        title: "Seragam",
        path: "/billing/uniform",
      },

      {
        id: "billing-tournament",
        title: "Turnamen",
        path: "/billing/tournament",
      },

      {
        id: "billing-fine",
        title: "Denda",
        path: "/billing/fine",
      },

      {
        id: "billing-payment",
        title: "Pembayaran",
        path: "/billing/payment",
      },
    ],
  },

  // =====================================================
  // KOPERASI
  // =====================================================

  {
    id: "koperasi",
    title: "Koperasi",
    icon: Savings,

    children: [
      {
        id: "simpanan",
        title: "Simpanan",
        path: "/koperasi/simpanan",
      },

      {
        id: "deposito",
        title: "Deposito",
        path: "/koperasi/deposito",
      },

      {
        id: "pinjaman",
        title: "Pinjaman",
        path: "/koperasi/pinjaman",
      },

      {
        id: "shu",
        title: "SHU",
        path: "/koperasi/shu",
      },
    ],
  },

  // =====================================================
  // POS
  // =====================================================

  {
    id: "pos",
    title: "Kasir POS",
    icon: PointOfSale,

    children: [
      {
        id: "kasir",
        title: "Kasir",
        path: "/pos",
      },

      {
        id: "produk",
        title: "Produk",
        path: "/pos/product",
      },

      {
        id: "promo",
        title: "Promo",
        path: "/pos/promo",
      },

      {
        id: "kategori-produk",
        title: "Kategori Produk",
        path: "/pos/category",
      },

      {
        id: "stok-produk",
        title: "Stok Produk",
        path: "/pos/stock",
      },
          ],
  },

  // =====================================================
  // MARKETPLACE
  // =====================================================

  {
    id: "marketplace",
    title: "Marketplace",
    icon: Store,

    children: [
      {
        id: "marketplace-catalog",
        title: "Katalog",
        path: "/marketplace/catalog",
      },

      {
        id: "marketplace-order",
        title: "Pesanan",
        path: "/marketplace/order",
      },

      {
        id: "marketplace-shipping",
        title: "Pengiriman",
        path: "/marketplace/shipping",
      },

      {
        id: "marketplace-review",
        title: "Ulasan",
        path: "/marketplace/review",
      },
    ],
  },

  // =====================================================
  // RENTAL
  // =====================================================

  {
    id: "rental",
    title: "Rental",
    icon: SportsTennis,

    children: [
      {
        id: "rental-court",
        title: "Sewa Lapangan",
        path: "/rental/court",
      },

      {
        id: "rental-table",
        title: "Sewa Meja",
        path: "/rental/table",
      },

      {
        id: "rental-robot",
        title: "Robot",
        path: "/rental/robot",
      },

      {
        id: "rental-bat",
        title: "Bet",
        path: "/rental/bat",
      },
    ],
  },

  // =====================================================
  // TURNAMEN
  // =====================================================

  {
    id: "tournament",
    title: "Turnamen",
    icon: EmojiEvents,

    children: [
      {
        id: "event",
        title: "Event",
        path: "/tournament",
      },

      {
        id: "pendaftaran-turnamen",
        title: "Pendaftaran",
        path: "/tournament/register",
      },

      {
        id: "drawing",
        title: "Drawing",
        path: "/tournament/drawing",
      },

      {
        id: "hasil",
        title: "Hasil",
        path: "/tournament/result",
      },

      {
        id: "sponsor-turnamen",
        title: "Sponsor",
        path: "/tournament/sponsor",
      },
    ],
  },

  // =====================================================
  // HRD
  // =====================================================

  {
    id: "hrd",
    title: "HRD & Payroll",
    icon: Badge,

    children: [
      {
        id: "hrd-attendance",
        title: "Absensi",
        path: "/hrd/attendance",
      },

      {
        id: "cuti",
        title: "Cuti",
        path: "/hrd/leave",
      },

      {
        id: "kpi",
        title: "KPI",
        path: "/hrd/kpi",
      },

      {
        id: "payroll",
        title: "Payroll",
        path: "/hrd/payroll",
      },

      {
        id: "honor",
        title: "Honor",
        path: "/hrd/honor",
      },
    ],
  },

  // =====================================================
  // PERGUDANGAN
  // =====================================================

  {
    id: "warehouse",
    title: "Pergudangan",
    icon: Warehouse,

    children: [
      {
        id: "barang-masuk",
        title: "Barang Masuk",
        path: "/warehouse/in",
      },

      {
        id: "barang-keluar",
        title: "Barang Keluar",
        path: "/warehouse/out",
      },

      {
        id: "stock-opname",
        title: "Stock Opname",
        path: "/warehouse/opname",
      },

      {
        id: "expired",
        title: "Expired",
        path: "/warehouse/expired",
      },

      {
        id: "fefo",
        title: "FEFO",
        path: "/warehouse/fefo",
      },
    ],
  },

  // =====================================================
  // SUPPLIER
  // =====================================================

  {
    id: "supplier",
    title: "Supplier & Procurement",
    icon: Inventory2,

    children: [
      {
        id: "supplier-master",
        title: "Supplier",
        path: "/supplier",
      },

      {
        id: "purchase-order",
        title: "Purchase Order",
        path: "/supplier/po",
      },

      {
        id: "penerimaan",
        title: "Penerimaan Barang",
        path: "/supplier/receive",
      },

      {
        id: "pembayaran-supplier",
        title: "Pembayaran",
        path: "/supplier/payment",
      },
    ],
  },

  // =====================================================
  // PIUTANG
  // =====================================================

  {
    id: "receivable",
    title: "Piutang",
    icon: Payments,

    children: [
      {
        id: "piutang-anggota",
        title: "Piutang Anggota",
        path: "/receivable/member",
      },

      {
        id: "aging-piutang",
        title: "Aging Piutang",
        path: "/receivable/aging",
      },
    ],
  },

  // =====================================================
  // HUTANG
  // =====================================================

  {
    id: "payable",
    title: "Hutang & Kewajiban",
    icon: AccountBalanceWallet,

    children: [
      {
        id: "hutang-supplier",
        title: "Hutang Supplier",
        path: "/payable/supplier",
      },

      {
        id: "aging-hutang",
        title: "Aging Hutang",
        path: "/payable/aging",
      },
    ],
  },
    // =====================================================
  // INVESTASI
  // =====================================================

  {
    id: "investment",
    title: "Investasi",
    icon: TrendingUp,

    children: [
      {
        id: "investasi-internal",
        title: "Investasi Internal",
        path: "/investment/internal",
      },

      {
        id: "investor",
        title: "Investor",
        path: "/investment/investor",
      },

      {
        id: "csr",
        title: "CSR",
        path: "/investment/csr",
      },

      {
        id: "roi",
        title: "ROI",
        path: "/investment/roi",
      },
    ],
  },

  // =====================================================
  // INVENTARIS
  // =====================================================

  {
    id: "asset",
    title: "Inventaris & Aset",
    icon: Apartment,

    children: [
      {
        id: "aset-tetap",
        title: "Aset Tetap",
        path: "/asset/fixed",
      },

      {
        id: "maintenance-aset",
        title: "Maintenance",
        path: "/asset/maintenance",
      },

      {
        id: "depresiasi",
        title: "Penyusutan",
        path: "/asset/depreciation",
      },
    ],
  },

  // =====================================================
  // CRM
  // =====================================================

  {
    id: "crm",
    title: "CRM & Komunikasi",
    icon: Campaign,

    children: [
      {
        id: "lead",
        title: "Calon Atlet",
        path: "/crm/lead",
      },

      {
        id: "broadcast",
        title: "Broadcast WhatsApp",
        path: "/crm/broadcast",
      },

      {
        id: "notification",
        title: "Notifikasi",
        path: "/crm/notification",
      },
    ],
  },

  // =====================================================
  // WALLET
  // =====================================================

  {
    id: "wallet",
    title: "Dompet Digital & Loyalty",
    icon: Wallet,

    children: [
      {
        id: "topup",
        title: "Top Up",
        path: "/wallet/topup",
      },

      {
        id: "transfer",
        title: "Transfer Saldo",
        path: "/wallet/transfer",
      },

      {
        id: "point",
        title: "Poin",
        path: "/wallet/point",
      },

      {
        id: "voucher",
        title: "Voucher",
        path: "/wallet/voucher",
      },
    ],
  },

  // =====================================================
  // APPROVAL
  // =====================================================

  {
    id: "approval",
    title: "Persetujuan",
    icon: FactCheck,

    children: [
      {
        id: "approval-loan",
        title: "Persetujuan Pinjaman",
        path: "/approval/loan",
      },

      {
        id: "approval-purchase",
        title: "Persetujuan Pembelian",
        path: "/approval/purchase",
      },

      {
        id: "approval-investment",
        title: "Persetujuan Investasi",
        path: "/approval/investment",
      },
    ],
  },

  // =====================================================
  // KEUANGAN
  // =====================================================

  {
    id: "finance",
    title: "Keuangan & Akuntansi",
    icon: Calculate,

    children: [
      {
        id: "kas",
        title: "Kas",
        path: "/finance/cash",
      },

      {
        id: "bank",
        title: "Bank",
        path: "/finance/bank",
      },

      {
        id: "coa",
        title: "Chart Of Account",
        path: "/finance/coa",
      },

      {
        id: "journal",
        title: "Jurnal Umum",
        path: "/finance/journal",
      },

      {
        id: "neraca",
        title: "Neraca",
        path: "/finance/balance-sheet",
      },

      {
        id: "laba-rugi",
        title: "Laba Rugi",
        path: "/finance/profit-loss",
      },
    ],
  },

  // =====================================================
  // DOKUMEN
  // =====================================================

  {
    id: "document",
    title: "Dokumen Digital",
    icon: Folder,

    children: [
      {
        id: "ktp",
        title: "KTP",
        path: "/document/ktp",
      },

      {
        id: "kk",
        title: "Kartu Keluarga",
        path: "/document/kk",
      },

      {
        id: "kontrak",
        title: "Kontrak",
        path: "/document/contract",
      },

      {
        id: "arsip",
        title: "Arsip Digital",
        path: "/document/archive",
      },
    ],
  },

  // =====================================================
  // LAPORAN
  // =====================================================

  {
    id: "report",
    title: "Laporan",
    icon: Assessment,

    children: [
      {
        id: "laporan-akademi",
        title: "Laporan Akademi",
        path: "/report/academy",
      },

      {
        id: "laporan-koperasi",
        title: "Laporan Koperasi",
        path: "/report/cooperative",
      },

      {
        id: "laporan-gudang",
        title: "Laporan Gudang",
        path: "/report/warehouse",
      },

      {
        id: "laporan-keuangan",
        title: "Laporan Keuangan",
        path: "/report/finance",
      },
    ],
  },

  // =====================================================
  // PENGATURAN
  // =====================================================

  {
    id: "settings",
    title: "Pengaturan",
    icon: Settings,

    children: [
      {
        id: "branding",
        title: "Branding",
        path: "/settings/branding",
      },

      {
        id: "backup",
        title: "Backup Database",
        path: "/settings/backup",
      },

      {
        id: "restore",
        title: "Restore Database",
        path: "/settings/restore",
      },

      {
        id: "audit-trail",
        title: "Audit Trail",
        path: "/settings/audit-trail",
      },
    ],
  },
];

export default menu;