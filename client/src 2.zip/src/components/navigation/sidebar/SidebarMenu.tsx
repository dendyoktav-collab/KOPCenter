import { List } from "@mui/material";
import { useMemo } from "react";

import menu from "../../../config/menu";
import type { MenuItem } from "../../../config/menu";

import { useSidebar } from "./SidebarContext";
import SidebarItem from "./SidebarItem";

function filterMenus(
  items: MenuItem[],
  keyword: string
): MenuItem[] {
  if (!keyword.trim()) {
    return items;
  }

  const lowerKeyword = keyword.toLowerCase();

  return items.reduce<MenuItem[]>(
    (result, item) => {
      const matched = item.title
        .toLowerCase()
        .includes(lowerKeyword);

      if (matched) {
        result.push(item);
        return result;
      }

      if (
        item.children &&
        item.children.length > 0
      ) {
        const children = filterMenus(
          item.children,
          keyword
        );

        if (children.length > 0) {
          result.push({
            ...item,
            children,
          });
        }
      }

      return result;
    },
    []
  );
}

export default function SidebarMenu() {
  const { search } = useSidebar();

  const menus = useMemo(() => {
    return filterMenus(menu, search);
  }, [search]);

  return (
    <List
      disablePadding
      sx={{
        px: 1,
        py: 0.5,
      }}
    >
      {menus.map((item) => (
        <SidebarItem
          key={item.id}
          item={item}
          level={0}
        />
      ))}
    </List>
  );
}