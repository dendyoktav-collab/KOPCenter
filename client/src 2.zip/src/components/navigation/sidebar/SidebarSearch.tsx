import {
  alpha,
  useTheme,
} from "@mui/material/styles";

import {
  Box,
  Fade,
  IconButton,
  InputAdornment,
  OutlinedInput,
  Tooltip,
} from "@mui/material";

import {
  Clear,
  Search,
} from "@mui/icons-material";

import {
  useEffect,
  useRef,
} from "react";

import { useAppSelector } from "../../../hooks/useAppSelector";

import { useSidebar } from "./SidebarContext";

export default function SidebarSearch() {
  const theme = useTheme();

  const sidebarOpen = useAppSelector(
    (state) => state.ui.sidebarOpen
  );

  const {
    search,
    setSearch,
  } = useSidebar();

  const inputRef =
    useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handler = (
      event: KeyboardEvent
    ) => {
      if (
        event.ctrlKey &&
        event.key.toLowerCase() === "k"
      ) {
        event.preventDefault();

        inputRef.current?.focus();
      }

      if (
        event.key === "Escape"
      ) {
        inputRef.current?.blur();
      }
    };

    window.addEventListener(
      "keydown",
      handler
    );

    return () =>
      window.removeEventListener(
        "keydown",
        handler
      );
  }, []);

  if (!sidebarOpen) {
    return null;
  }

  return (
    <Fade in timeout={250}>
      <Box
        sx={{
          p: 2,

          bgcolor:
            "background.paper",
        }}
      >
        <OutlinedInput
          inputRef={inputRef}
          fullWidth
          size="small"
          value={search}
          placeholder="Cari menu..."
          onChange={(e) =>
            setSearch(
              e.target.value
            )
          }
          startAdornment={
            <InputAdornment position="start">
              <Search
                fontSize="small"
              />
            </InputAdornment>
          }
          endAdornment={
            search.length > 0 && (
              <InputAdornment position="end">
                <Tooltip title="Clear">
                  <IconButton
                    size="small"
                    onClick={() =>
                      setSearch("")
                    }
                  >
                    <Clear
                      fontSize="small"
                    />
                  </IconButton>
                </Tooltip>
              </InputAdornment>
            )
          }
          sx={{
            borderRadius: 3,

            transition:
              ".25s ease",

            bgcolor: alpha(
              theme.palette.primary.main,
              0.03
            ),

            "& .MuiOutlinedInput-notchedOutline":
              {
                borderColor:
                  alpha(
                    theme.palette.primary.main,
                    .15
                  ),
              },

            "&:hover .MuiOutlinedInput-notchedOutline":
              {
                borderColor:
                  theme.palette.primary.main,
              },

            "&.Mui-focused .MuiOutlinedInput-notchedOutline":
              {
                borderWidth: 2,
              },
          }}
        />
      </Box>
    </Fade>
  );
}