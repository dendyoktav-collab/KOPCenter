import {
  createContext,
  PropsWithChildren,
  useCallback,
  useContext,
  useMemo,
  useState,
} from "react";

export interface SidebarContextValue {
  search: string;
  setSearch: (value: string) => void;

  expanded: Record<string, boolean>;
  toggleExpanded: (id: string) => void;
  expand: (id: string) => void;
  collapse: (id: string) => void;
  collapseAll: () => void;

  favorites: string[];
  toggleFavorite: (id: string) => void;

  activeMenu: string;
  setActiveMenu: (id: string) => void;
}

const SidebarContext =
  createContext<SidebarContextValue | null>(
    null
  );

export function SidebarProvider({
  children,
}: PropsWithChildren) {
  const [search, setSearch] =
    useState("");

  const [expanded, setExpanded] =
    useState<Record<string, boolean>>(
      {}
    );

  const [favorites, setFavorites] =
    useState<string[]>([]);

  const [activeMenu, setActiveMenu] =
    useState("");

  const toggleExpanded =
    useCallback((id: string) => {
      setExpanded((prev) => ({
        ...prev,
        [id]: !prev[id],
      }));
    }, []);

  const expand = useCallback(
    (id: string) => {
      setExpanded((prev) => ({
        ...prev,
        [id]: true,
      }));
    },
    []
  );

  const collapse = useCallback(
    (id: string) => {
      setExpanded((prev) => ({
        ...prev,
        [id]: false,
      }));
    },
    []
  );

  const collapseAll =
    useCallback(() => {
      setExpanded({});
    }, []);

  const toggleFavorite =
    useCallback((id: string) => {
      setFavorites((prev) => {
        if (prev.includes(id)) {
          return prev.filter(
            (item) => item !== id
          );
        }

        return [...prev, id];
      });
    }, []);

  const value = useMemo(
    () => ({
      search,
      setSearch,

      expanded,
      toggleExpanded,

      expand,
      collapse,
      collapseAll,

      favorites,
      toggleFavorite,

      activeMenu,
      setActiveMenu,
    }),
    [
      search,
      expanded,
      favorites,
      activeMenu,
      toggleExpanded,
      expand,
      collapse,
      collapseAll,
      toggleFavorite,
    ]
  );

  return (
    <SidebarContext.Provider
      value={value}
    >
      {children}
    </SidebarContext.Provider>
  );
}

export function useSidebar() {
  const context =
    useContext(SidebarContext);

  if (!context) {
    throw new Error(
      "useSidebar must be used inside SidebarProvider."
    );
  }

  return context;
}