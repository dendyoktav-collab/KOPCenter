import { Box, Divider, Drawer } from "@mui/material";

import {
  DRAWER_COLLAPSE_WIDTH,
  DRAWER_WIDTH,
} from "../../../config/constants";

import { useAppSelector } from "../../../hooks/useAppSelector";

import { SidebarProvider } from "./SidebarContext";

import SidebarHeader from "./SidebarHeader";
import SidebarSearch from "./SidebarSearch";
import SidebarMenu from "./SidebarMenu";
import SidebarFooter from "./SidebarFooter";

export default function Sidebar() {
  const sidebarOpen = useAppSelector(
    (state) => state.ui.sidebarOpen
  );

  const drawerWidth = sidebarOpen
    ? DRAWER_WIDTH
    : DRAWER_COLLAPSE_WIDTH;

  return (
    <SidebarProvider>
      <Drawer
        variant="permanent"
        sx={{
          width: drawerWidth,
          flexShrink: 0,

          "& .MuiDrawer-paper": {
            width: drawerWidth,

            display: "flex",

            flexDirection: "column",

            overflow: "hidden",

            transition:
              "width .25s ease",

            borderRight: "1px solid",

            borderColor: "divider",

            bgcolor: "background.paper",

            boxSizing: "border-box",
          },
        }}
      >
        <SidebarHeader />

        <Divider />

        <SidebarSearch />

        <Divider />

        <Box
          sx={{
            flex: 1,

            overflowY: "auto",

            overflowX: "hidden",

            py: 1,

            "&::-webkit-scrollbar": {
              width: 6,
            },

            "&::-webkit-scrollbar-track": {
              background: "transparent",
            },

            "&::-webkit-scrollbar-thumb": {
              borderRadius: 20,

              bgcolor: "grey.400",

              background:
                "rgba(0,0,0,.20)",
            },

            "&::-webkit-scrollbar-thumb:hover": {
              background:
                "rgba(0,0,0,.35)",
            },
          }}
        >
          <SidebarMenu />
        </Box>

        <Divider />

        <SidebarFooter />
      </Drawer>
    </SidebarProvider>
  );
}