import {
  Box,
  IconButton,
  Tooltip,
  Typography,
  Fade,
} from "@mui/material";

import {
  MenuOpen,
  Menu,
} from "@mui/icons-material";

import { useTheme } from "@mui/material/styles";

import { useAppDispatch } from "../../../hooks/useAppDispatch";
import { useAppSelector } from "../../../hooks/useAppSelector";

import { toggleSidebar } from "../../../store/uiSlice";

export default function SidebarHeader() {
  const theme = useTheme();

  const dispatch = useAppDispatch();

  const sidebarOpen = useAppSelector(
    (state) => state.ui.sidebarOpen
  );

  return (
    <Box
      sx={{
        height: 72,

        px: sidebarOpen ? 2 : 1,

        display: "flex",

        alignItems: "center",

        justifyContent: sidebarOpen
          ? "space-between"
          : "center",

        transition: "all .25s",

        bgcolor: "background.paper",

        position: "sticky",

        top: 0,

        zIndex: 2,
      }}
    >
      <Fade
        in={sidebarOpen}
        timeout={250}
      >
        <Box
          sx={{
            display: sidebarOpen
              ? "flex"
              : "none",

            alignItems: "center",

            gap: 1.5,

            overflow: "hidden",
          }}
        >
          <Box
            sx={{
              width: 44,

              height: 44,

              borderRadius: 2.5,

              bgcolor: "primary.main",

              color: "#fff",

              display: "flex",

              justifyContent: "center",

              alignItems: "center",

              fontWeight: 700,

              fontSize: 20,

              boxShadow:
                theme.shadows[4],

              flexShrink: 0,

              userSelect: "none",
            }}
          >
            K
          </Box>

          <Box>
            <Typography
              variant="subtitle1"
              fontWeight={700}
              lineHeight={1.1}
              noWrap
            >
              KOPCenter
            </Typography>

            <Typography
              variant="caption"
              color="text.secondary"
              noWrap
            >
              Enterprise ERP
            </Typography>
          </Box>
        </Box>
      </Fade>

      <Tooltip
        title={
          sidebarOpen
            ? "Collapse Sidebar"
            : "Expand Sidebar"
        }
      >
        <IconButton
          onClick={() =>
            dispatch(toggleSidebar())
          }
          sx={{
            width: 40,

            height: 40,

            borderRadius: 2,

            transition: ".25s",

            "&:hover": {
              bgcolor: "primary.main",

              color: "#fff",

              transform:
                "rotate(180deg)",
            },
          }}
        >
          {sidebarOpen ? (
            <MenuOpen />
          ) : (
            <Menu />
          )}
        </IconButton>
      </Tooltip>
    </Box>
  );
}