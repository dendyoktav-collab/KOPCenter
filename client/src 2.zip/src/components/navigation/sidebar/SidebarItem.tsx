import {
  Fragment,
  memo,
  useEffect,
  useMemo,
} from "react";

import {
  Badge,
  Box,
  Collapse,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Tooltip,
} from "@mui/material";

import {
  ExpandLess,
  ExpandMore,
  Star,
  StarBorder,
} from "@mui/icons-material";

import {
  Link,
  useLocation,
} from "react-router-dom";

import type { MenuItem } from "../../../config/menu";

import { useAppSelector } from "../../../hooks/useAppSelector";

import { useSidebar } from "./SidebarContext";

interface SidebarItemProps {
  item: MenuItem;
  level: number;
}

function SidebarItem({
  item,
  level,
}: SidebarItemProps) {
  const location =
    useLocation();

  const sidebarOpen =
    useAppSelector(
      (state) =>
        state.ui.sidebarOpen
    );

  const {
    expanded,
    toggleExpanded,

    favorites,
    toggleFavorite,

    expand,
  } = useSidebar();

  const Icon = item.icon;

  const hasChildren =
    Boolean(item.children?.length);

  const isExpanded =
    expanded[item.id] ?? false;

  const isFavorite =
    favorites.includes(item.id);

  const isSelected =
    item.path ===
    location.pathname;
      const hasActiveChild =
    useMemo(() => {
      if (!item.children)
        return false;

      const check = (
        menus: MenuItem[]
      ): boolean => {
        for (const menu of menus) {
          if (
            menu.path ===
            location.pathname
          ) {
            return true;
          }

          if (
            menu.children &&
            check(menu.children)
          ) {
            return true;
          }
        }

        return false;
      };

      return check(
        item.children
      );
    }, [
      item.children,
      location.pathname,
    ]);

  useEffect(() => {
    if (
      hasChildren &&
      hasActiveChild
    ) {
      expand(item.id);
    }
  }, [
    hasChildren,
    hasActiveChild,
    expand,
    item.id,
  ]);

  const paddingLeft =
    sidebarOpen
      ? 2 + level * 2
      : 1.5;
        if (hasChildren) {
    return (
      <Fragment>
        <Tooltip
          placement="right"
          title={
            sidebarOpen
              ? ""
              : item.title
          }
        >
          <ListItemButton
            onClick={() =>
              toggleExpanded(
                item.id
              )
            }
            sx={{
              borderRadius: 2,

              minHeight: 48,

              mx: 1,

              mb: .5,

              pl: paddingLeft,

              justifyContent:
                sidebarOpen
                  ? "initial"
                  : "center",

              transition:
                ".25s",

              "&:hover": {
                bgcolor:
                  "action.hover",
              },
            }}
          >
            {Icon && (
              <ListItemIcon
                sx={{
                  minWidth:
                    sidebarOpen
                      ? 40
                      : 0,

                  justifyContent:
                    "center",
                }}
              >
                <Icon />
              </ListItemIcon>
            )}

            {sidebarOpen && (
              <ListItemText
                primary={
                  item.title
                }
              />
            )}

            {sidebarOpen &&
              (isExpanded ? (
                <ExpandLess />
              ) : (
                <ExpandMore />
              ))}
          </ListItemButton>
        </Tooltip>
                <Collapse
          in={isExpanded}
          timeout="auto"
          unmountOnExit
        >
          <List
            disablePadding
          >
            {item.children!.map(
              (child) => (
                <SidebarItem
                  key={child.id}
                  item={child}
                  level={
                    level + 1
                  }
                />
              )
            )}
          </List>
        </Collapse>
      </Fragment>
    );
  }

  return (
    <Tooltip
      placement="right"
      title={
        sidebarOpen
          ? ""
          : item.title
      }
    >
      <ListItemButton
        component={Link}
        to={item.path || "#"}
        selected={isSelected}
        sx={{
          borderRadius: 2,

          minHeight: 48,

          mx: 1,

          mb: .5,

          pl: paddingLeft,

          justifyContent:
            sidebarOpen
              ? "initial"
              : "center",

          transition:
            "all .2s ease",

          "&.Mui-selected": {
            bgcolor:
              "primary.main",

            color: "#fff",

            "& .MuiListItemIcon-root":
              {
                color: "#fff",
              },

            "&:hover": {
              bgcolor:
                "primary.dark",
            },
          },

          "&:hover": {
            bgcolor:
              isSelected
                ? "primary.dark"
                : "action.hover",
          },
        }}
      ></ListItemButton>
              {Icon && (
          <ListItemIcon
            sx={{
              minWidth:
                sidebarOpen
                  ? 40
                  : 0,

              justifyContent:
                "center",

              color:
                isSelected
                  ? "#fff"
                  : "inherit",
            }}
          >
            {item.badge ? (
              <Badge
                badgeContent={
                  item.badge
                }
                color={
                  item.badgeColor ??
                  "error"
                }
              >
                <Icon />
              </Badge>
            ) : (
              <Icon />
            )}
          </ListItemIcon>
        )}

        {sidebarOpen && (
          <>
            <ListItemText
              primary={
                item.title
              }
              primaryTypographyProps={{
                noWrap: true,

                fontWeight:
                  isSelected
                    ? 700
                    : 500,

                fontSize: 14,
              }}
            />
                        <Box
              display="flex"
              alignItems="center"
              gap={.5}
            >
              {isFavorite ? (
                <Star
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();

                    toggleFavorite(
                      item.id
                    );
                  }}
                  sx={{
                    fontSize: 18,

                    color:
                      "#FFC107",

                    cursor:
                      "pointer",

                    transition:
                      ".2s",

                    "&:hover": {
                      transform:
                        "scale(1.15)",
                    },
                  }}
                />
              ) : (
                <StarBorder
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();

                    toggleFavorite(
                      item.id
                    );
                  }}
                  sx={{
                    fontSize: 18,

                    cursor:
                      "pointer",

                    color:
                      "text.disabled",

                    transition:
                      ".2s",

                    "&:hover": {
                      color:
                        "#FFC107";

                      transform:
                        "scale(1.15)";
                    },
                  }}
                />
              )}
            </Box>
          </>
        )}
      </ListItemButton>
    </Tooltip>
  );
    const isDisabled =
    item.disabled === true;

  if (isDisabled) {
    return (
      <Tooltip
        title={
          sidebarOpen
            ? ""
            : item.title
        }
        placement="right"
      >
        <Box>
          <ListItemButton
            disabled
            sx={{
              minHeight: 48,

              borderRadius: 2,

              mx: 1,

              mb: .5,

              pl: paddingLeft,

              justifyContent:
                sidebarOpen
                  ? "initial"
                  : "center",

              opacity: .55,
            }}
          >
            {Icon && (
              <ListItemIcon
                sx={{
                  minWidth:
                    sidebarOpen
                      ? 40
                      : 0,

                  justifyContent:
                    "center",
                }}
              >
                <Icon />
              </ListItemIcon>
            )}

            {sidebarOpen && (
              <ListItemText
                primary={item.title}
              />
            )}
          </ListItemButton>
        </Box>
      </Tooltip>
    );
  }
}
export default memo(SidebarItem);