import { useMemo, useState } from "react";
import {
  AppBar,
  Avatar,
  Badge,
  Box,
  Chip,
  Divider,
  IconButton,
  InputBase,
  ListItemIcon,
  ListItemText,
  Menu,
  MenuItem,
  Paper,
  Stack,
  Toolbar,
  Tooltip,
  Typography,
} from "@mui/material";

import {
  Menu as MenuIcon,
  NotificationsNone,
  AccountCircle,
  DarkModeOutlined,
  LightModeOutlined,
  Fullscreen,
  FullscreenExit,
  Logout,
  Search,
  Settings,
  Apps,
  HelpOutline,
  PersonOutline,
  KeyboardArrowDown,
  CampaignOutlined,
  TaskAlt,
  MonetizationOnOutlined,
  GroupsOutlined,
} from "@mui/icons-material";

import { alpha } from "@mui/material/styles";

import { useAppDispatch } from "../hooks/useAppDispatch";
import { useAppSelector } from "../hooks/useAppSelector";

import {
  toggleSidebar,
  toggleDarkMode,
} from "../store/uiSlice";

import Breadcrumb from "./Breadcrumb";

interface NotificationItem {
  id: number;
  title: string;
  description: string;
  color:
    | "success"
    | "warning"
    | "error"
    | "info";
}

export default function Topbar() {
  const dispatch = useAppDispatch();

  const darkMode = useAppSelector(
    (state) => state.ui.darkMode
  );

  const [profileAnchor, setProfileAnchor] =
    useState<null | HTMLElement>(null);

  const [notificationAnchor, setNotificationAnchor] =
    useState<null | HTMLElement>(null);

  const [isFullscreen, setIsFullscreen] =
    useState(false);

  const profileOpen = Boolean(profileAnchor);

  const notificationOpen = Boolean(
    notificationAnchor
  );

  const notifications =
    useMemo<NotificationItem[]>(
      () => [
        {
          id: 1,
          title: "Anggota Baru",
          description:
            "12 anggota baru telah terdaftar hari ini.",
          color: "success",
        },
        {
          id: 2,
          title: "Pinjaman Jatuh Tempo",
          description:
            "5 pinjaman akan jatuh tempo minggu ini.",
          color: "warning",
        },
        {
          id: 3,
          title: "Kas Harian",
          description:
            "Laporan kas harian siap diperiksa.",
          color: "info",
        },
      ],
      []
    );

  const toggleFullscreen = async () => {
    if (!document.fullscreenElement) {
      await document.documentElement.requestFullscreen();
      setIsFullscreen(true);
    } else {
      await document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  return (
    <AppBar
      position="sticky"
      elevation={0}
      color="inherit"
      sx={{
        backdropFilter: "blur(18px)",
        background: alpha("#ffffff", 0.92),
        borderBottom: "1px solid",
        borderColor: "divider",
        color: "text.primary",
        zIndex: (theme) =>
          theme.zIndex.drawer + 1,
      }}
    >
      <Toolbar
        sx={{
          minHeight: 72,
          px: 3,
          gap: 2,
        }}
      >
        <Tooltip title="Sidebar">
          <IconButton
            onClick={() =>
              dispatch(toggleSidebar())
            }
            sx={{
              borderRadius: 3,
            }}
          >
            <MenuIcon />
          </IconButton>
        </Tooltip>

        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            minWidth: 220,
          }}
        >
          <Typography
            variant="h6"
            fontWeight={700}
          >
            Dashboard
          </Typography>

          <Breadcrumb />
        </Box>

        <Box sx={{ flex: 1 }} />

        <Paper
          elevation={0}
          sx={{
            display: "flex",
            alignItems: "center",
            width: 380,
            height: 46,
            px: 2,
            borderRadius: 4,
            border: "1px solid",
            borderColor: "divider",
            backgroundColor: (theme) =>
              alpha(
                theme.palette.primary.main,
                0.04
              ),
            transition: ".25s",
            "&:hover": {
              borderColor: "primary.main",
              backgroundColor: (theme) =>
                alpha(
                  theme.palette.primary.main,
                  0.08
                ),
            },
          }}
        >
          <Search
            sx={{
              mr: 1.5,
              color: "text.secondary",
            }}
          />

          <InputBase
            fullWidth
            placeholder="Cari menu, anggota, transaksi..."
          />

          <Chip
            size="small"
            label="Ctrl K"
            variant="outlined"
          />
        </Paper>

        <Stack
          direction="row"
          spacing={1}
          alignItems="center"
        >
          <Tooltip title="Quick Menu">
            <IconButton
              sx={{
                borderRadius: 3,
              }}
            >
              <Apps />
            </IconButton>
          </Tooltip>

          <Tooltip title="Dark Mode">
            <IconButton
              sx={{
                borderRadius: 3,
              }}
              onClick={() =>
                dispatch(toggleDarkMode())
              }
            >
              {darkMode ? (
                <LightModeOutlined />
              ) : (
                <DarkModeOutlined />
              )}
            </IconButton>
          </Tooltip>

          <Tooltip title="Fullscreen">
            <IconButton
              sx={{
                borderRadius: 3,
              }}
              onClick={toggleFullscreen}
            >
              {isFullscreen ? (
                <FullscreenExit />
              ) : (
                <Fullscreen />
              )}
            </IconButton>
          </Tooltip>

          <Tooltip title="Notifikasi">
            <IconButton
              sx={{
                borderRadius: 3,
              }}
              onClick={(e) =>
                setNotificationAnchor(
                  e.currentTarget
                )
              }
            >
              <Badge
                badgeContent={
                  notifications.length
                }
                color="error"
              >
                <NotificationsNone />
              </Badge>
            </IconButton>
          </Tooltip>
        </Stack>

        <Divider
          flexItem
          orientation="vertical"
        />

        <Stack
          direction="row"
          spacing={1.5}
          alignItems="center"
          sx={{
            cursor: "pointer",
            px: 1,
            py: .5,
            borderRadius: 3,
            transition: ".25s",
            "&:hover": {
              backgroundColor: (theme) =>
                alpha(
                  theme.palette.primary.main,
                  .06
                ),
            },
          }}
          onClick={(e) =>
            setProfileAnchor(
              e.currentTarget
            )
          }
        >
          <Avatar
            sx={{
              width: 42,
              height: 42,
              bgcolor: "primary.main",
              fontWeight: 700,
            }}
          >
            D
          </Avatar>

          <Box>
            <Typography
              fontWeight={700}
              fontSize={14}
            >
              Mochamad Dendi
            </Typography>

            <Typography
              variant="caption"
              color="text.secondary"
            >
              Super Administrator
            </Typography>
          </Box>

          <KeyboardArrowDown />
        </Stack>

        <Menu
          anchorEl={notificationAnchor}
          open={notificationOpen}
          onClose={() =>
            setNotificationAnchor(null)
          }
          PaperProps={{
            sx: {
              width: 360,
              borderRadius: 4,
              mt: 1,
            },
          }}
        >
          <Box p={2}>
            <Typography
              fontWeight={700}
              fontSize={18}
            >
              Notifikasi
            </Typography>

            <Typography
              variant="body2"
              color="text.secondary"
            >
              Aktivitas terbaru KOPCenter
            </Typography>
          </Box>

          <Divider />

          {notifications.map((item) => (
            <MenuItem
              key={item.id}
              sx={{
                py: 1.8,
                alignItems: "flex-start",
              }}
            >
              <ListItemIcon>
                {item.color ===
                "success" ? (
                  <TaskAlt
                    color="success"
                  />
                ) : item.color ===
                  "warning" ? (
                  <CampaignOutlined
                    color="warning"
                  />
                ) : item.color ===
                  "info" ? (
                  <GroupsOutlined
                    color="primary"
                  />
                ) : (
                  <MonetizationOnOutlined color="error" />
                )}
              </ListItemIcon>

              <ListItemText
                primary={item.title}
                secondary={
                  item.description
                }
              />
            </MenuItem>
          ))}
                    <Divider />

          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              p: 1.5,
            }}
          >
            <Chip
              label="Lihat Semua Notifikasi"
              color="primary"
              variant="outlined"
              clickable
            />
          </Box>
        </Menu>

        {/* =========================
            PROFILE MENU
        ========================== */}

        <Menu
          anchorEl={profileAnchor}
          open={profileOpen}
          onClose={() => setProfileAnchor(null)}
          PaperProps={{
            sx: {
              mt: 1,
              width: 300,
              borderRadius: 4,
              overflow: "hidden",
            },
          }}
        >
          <Box
            sx={{
              px: 3,
              py: 2.5,
              background: (theme) =>
                `linear-gradient(135deg,
                ${theme.palette.primary.main},
                ${theme.palette.primary.light})`,
              color: "#fff",
            }}
          >
            <Stack
              direction="row"
              spacing={2}
              alignItems="center"
            >
              <Avatar
                sx={{
                  width: 56,
                  height: 56,
                  bgcolor: "#fff",
                  color: "primary.main",
                  fontWeight: 700,
                  fontSize: 22,
                }}
              >
                D
              </Avatar>

              <Box>
                <Typography
                  fontWeight={700}
                >
                  Mochamad Dendi
                </Typography>

                <Typography
                  variant="body2"
                  sx={{
                    opacity: .9,
                  }}
                >
                  Super Administrator
                </Typography>

                <Typography
                  variant="caption"
                  sx={{
                    opacity: .8,
                  }}
                >
                  dendyoktav@gmail.com
                </Typography>
              </Box>
            </Stack>
          </Box>

          <MenuItem
            onClick={() =>
              setProfileAnchor(null)
            }
          >
            <ListItemIcon>
              <PersonOutline />
            </ListItemIcon>

            <ListItemText
              primary="Profil Saya"
              secondary="Kelola akun pengguna"
            />
          </MenuItem>

          <MenuItem
            onClick={() =>
              setProfileAnchor(null)
            }
          >
            <ListItemIcon>
              <Settings />
            </ListItemIcon>

            <ListItemText
              primary="Pengaturan"
              secondary="Konfigurasi aplikasi"
            />
          </MenuItem>

          <MenuItem
            onClick={() =>
              setProfileAnchor(null)
            }
          >
            <ListItemIcon>
              <HelpOutline />
            </ListItemIcon>

            <ListItemText
              primary="Pusat Bantuan"
              secondary="Panduan penggunaan"
            />
          </MenuItem>

          <Divider />

          <MenuItem
            sx={{
              color: "error.main",
            }}
            onClick={() =>
              setProfileAnchor(null)
            }
          >
            <ListItemIcon>
              <Logout color="error" />
            </ListItemIcon>

            <ListItemText
              primary="Logout"
              secondary="Keluar dari aplikasi"
            />
          </MenuItem>
        </Menu>
      </Toolbar>
    </AppBar>
  );
}